import torch
import torch.nn as nn
import torch.nn.functional as F

class RAIN(nn.Module):
    def __init__(self, dims_in, eps=1e-5):
        '''Compute the instance normalization within only the background region, in which
            the mean and standard variance are measured from the features in background region.
        '''
        super(RAIN, self).__init__()
        self.foreground_gamma = nn.Parameter(torch.zeros(dims_in), requires_grad=True)
        self.foreground_beta = nn.Parameter(torch.zeros(dims_in), requires_grad=True)
        self.background_gamma = nn.Parameter(torch.zeros(dims_in), requires_grad=True)
        self.background_beta = nn.Parameter(torch.zeros(dims_in), requires_grad=True)
        self.eps = eps

    def forward(self, x, mask):
        
        
        # fill the blank
        ########################################################################

        
        
        ########################################################################
        
        mask = F.interpolate(mask.detach(), size = (x.shape[2],x.shape[2]))


        mean_fore, std_fore = self.get_foreground_mean_std(x * mask, mask) 
        mean_back, std_back = self.get_foreground_mean_std(x * (1-mask), 1-mask) # (region_back, mask_back) 

        
        forgamma  = self.foreground_gamma[None, :, None, None]
        forbeta   = self.foreground_beta[None, :, None, None] 
        normalized_foreground = ( (forgamma+1)  *  ( (x - mean_fore) / std_fore * std_back + mean_back ) + forbeta ) * mask

        
        backgamma = self.background_gamma[None, :, None, None]
        backbeta  = self.background_beta[None, :, None, None]
        normalized_background = ( (backgamma+1) *  ( (x - mean_back) / std_back) + backbeta ) * (1 - mask)

        
        ########################################################################
        
        


        ########################################################################


        return normalized_foreground + normalized_background
    
    def mysum(self, tensor):
        list = []
        for i in range(tensor.shape[1]):
            channelsum = torch.sum(tensor[:,i])
            list.append(channelsum)

        result = torch.stack(list)
        result = result[None,:]
        list.clear()

        return result

    def get_foreground_mean_std(self, region, mask):

        # fill the blank
##        print("\n\n###################   get_foreground_mean_std   ################################\n\n")
        
        
        ########################################################################
        sum = self.mysum(region)
            
        num = self.mysum(mask)

        mu = sum / (num + self.eps)
        
        mean = mu[:, :, None, None]

        upper = (region + (1 - mask)*mean - mean) ** 2

        var = self.mysum(upper) / (num + self.eps)
                
        var = var[:, :, None, None]
        
        ########################################################################
        
        


        return mean, torch.sqrt(var+self.eps)
